const functions = require('@google-cloud/functions-framework');
const { Firestore } = require('@google-cloud/firestore');

const firestore = new Firestore();

functions.http('getUsers', async (req, res) => {
  try {
    const users = await firestore.collection('users').get();
    const usersData = users.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    res.status(200).json(usersData);
  } catch (error) {
    res.status(500).send('Error retrieving users');
  }
});