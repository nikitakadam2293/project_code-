import { GetServerSideProps } from 'next';

type User = {
  id: string;
  name: string;
  email: string;
};

export const getServerSideProps: GetServerSideProps = async () => {
  const res = await fetch(`https://<your-cloud-function-url>/users`);
  const users = await res.json();
  return { props: { users } };
};

const Dashboard: React.FC<{ users: User[] }> = ({ users }) => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold">User Dashboard</h1>
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border">ID</th>
            <th className="py-2 px-4 border">Name</th>
            <th className="py-2 px-4 border">Email</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td className="py-2 px-4 border">{user.id}</td>
              <td className="py-2 px-4 border">{user.name}</td>
              <td className="py-2 px-4 border">{user.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Dashboard;